"""Create precise Chinese typography on fresh transparent canvases."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

r=Path(__file__).resolve().parent
serif='/usr/share/fonts/opentype/noto/NotoSerifCJK-Regular.ttc'
sans='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
W,H=1024,1536
im=Image.new('RGBA',(W,H),(0,0,0,0));d=ImageDraw.Draw(im)
def text(y,value,size=34,color='#284957',font=serif,x=512,anchor='mm',halo=False):
    f=ImageFont.truetype(font,size)
    while d.textlength(value,font=f)>870 and size>16:
        size-=1;f=ImageFont.truetype(font,size)
    d.text((x,y),value,font=f,fill=color,anchor=anchor,stroke_width=1 if halo else 0,stroke_fill=(8,21,40,215))
text(79,'管小科 · 中秋特别典藏',27,'#f5dfb5',sans,halo=True)
text(142,'月落西财 · 桂遇广寒',51,'#fff0d7',halo=True)
text(1375,'月满西财 · 此心安处',48,'#ffebc5',halo=True)
text(1440,'中秋快乐，我们西财见。',27,'#f7e7c9',halo=True)
text(1494,'No.0003',22,'#f4dbae',sans,x=931,anchor='rm',halo=True)
im.save(r/'assets/text.png')
im=Image.new('RGBA',(W,H),(0,0,0,0));d=ImageDraw.Draw(im)
text(208,'中 秋 特 别 典 藏',28,'#87652d',sans)
text(349,'管小科',78,'#294759')
text(423,'桂 香 入 梦 · 月 满 西 财',24,'#927341',sans)
for y,value in zip((698,776,850,934,1008,1082),('桂香入梦，月满西财。','无论相隔多远，','思念，都照在同一轮月光下。','团圆，未必只在故乡。','师长同窗相伴，','此心安处，亦是吾乡。')):
    text(y,value,35)
text(1180,'中秋快乐，我们西财见。',32,'#927039')
text(1274,'西南财经大学',26,font=sans)
text(1321,'管理科学与工程学院',25,font=sans)
text(1420,'典藏编号：〇〇〇三',31,'#fff0d7',halo=True)
im.save(r/'assets/back-text.png')
print('Front No.0003 and Chinese-only script-inspired back typography created')
