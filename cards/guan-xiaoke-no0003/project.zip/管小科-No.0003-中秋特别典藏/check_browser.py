import json
import sys
from pathlib import Path
from playwright.sync_api import sync_playwright

root = Path(__file__).parent
errors = []
with sync_playwright() as p:
    browser = p.chromium.launch(executable_path='/usr/bin/chromium', headless=True, args=['--no-sandbox', '--enable-webgl', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'])
    page = browser.new_page(viewport={'width':1440,'height':1000}, device_scale_factor=1)
    page.on('pageerror', lambda e: errors.append(str(e)))
    page.on('console', lambda m: errors.append(m.text) if m.type=='error' else None)
    page.goto(sys.argv[1] if len(sys.argv)>1 else 'http://127.0.0.1:4184')
    page.wait_for_function('window.__holo?.ready === true', timeout=60000)
    page.wait_for_timeout(1500)
    page.screenshot(path=str(root/'renders/web-front.png'))
    page.locator('#stage canvas').screenshot(path=str(root/'renders/card-front.png'))
    before=page.evaluate('window.__holo.root.rotation.y')
    box=page.locator('#stage').bounding_box()
    page.mouse.move(box['x']+box['width']/2,box['y']+box['height']/2)
    page.mouse.down(); page.mouse.move(box['x']+box['width']/2+80,box['y']+box['height']/2+25,steps=8); page.mouse.up()
    page.wait_for_timeout(800)
    after=page.evaluate('window.__holo.root.rotation.y')
    assert abs(after-before)>.1
    page.locator('#stage canvas').screenshot(path=str(root/'renders/card-tilted.png'))
    page.locator('#flip').click(); page.wait_for_function('Math.abs(window.__holo.root.rotation.y-Math.PI)<.03', timeout=60000)
    assert page.locator('#view-label').inner_text()=='背面'
    assert abs(page.evaluate('window.__holo.root.rotation.y')-3.14159)<.03
    page.locator('#stage canvas').screenshot(path=str(root/'renders/card-back.png'))
    page.locator('#flip').click(); page.wait_for_function('Math.abs(window.__holo.root.rotation.y)<.03', timeout=60000)
    assert page.locator('#view-label').inner_text()=='正面'
    page.locator('#foil').fill('0.4'); page.locator('#foil').dispatch_event('input')
    assert page.evaluate('window.__holo.uniforms.uFoil.value')==.4
    page.locator('#foil').fill('1'); page.locator('#foil').dispatch_event('input')
    page.locator('#auto').click(); page.wait_for_timeout(500)
    assert page.locator('#auto').get_attribute('aria-pressed')=='true'
    page.locator('#reset').click(); page.wait_for_timeout(700)
    assert page.locator('#auto').get_attribute('aria-pressed')=='false'
    with page.expect_download() as download:
        page.locator('#save').click()
    download.value.save_as(str(root/'renders/saved-card.png'))
    page.set_viewport_size({'width':390,'height':844}); page.wait_for_timeout(800)
    assert page.evaluate('document.documentElement.scrollWidth <= innerWidth')
    page.screenshot(path=str(root/'renders/mobile.png'),full_page=True)
    context = browser.new_context(viewport={'width':390,'height':844}, is_mobile=True, has_touch=True, device_scale_factor=1)
    mobile = context.new_page()
    mobile.on('pageerror', lambda e: errors.append(str(e)))
    mobile.goto(sys.argv[1] if len(sys.argv)>1 else 'http://127.0.0.1:4184')
    mobile.wait_for_function('window.__holo?.ready === true', timeout=60000)
    mobile.locator('#flip').tap()
    mobile.wait_for_function('Math.abs(window.__holo.root.rotation.y-Math.PI)<.03', timeout=60000)
    assert mobile.locator('#view-label').inner_text()=='背面'
    mobile.locator('#reset').tap()
    mobile.wait_for_function('Math.abs(window.__holo.root.rotation.y+.13)<.03', timeout=60000)
    mb=mobile.locator('#stage').bounding_box()
    start=mobile.evaluate('window.__holo.root.rotation.y')
    session=context.new_cdp_session(mobile)
    x=mb['x']+mb['width']/2; y=mb['y']+mb['height']/2
    session.send('Input.dispatchTouchEvent',{'type':'touchStart','touchPoints':[{'x':x,'y':y}]})
    for offset in (10,20,30,40,50):
        session.send('Input.dispatchTouchEvent',{'type':'touchMove','touchPoints':[{'x':x+offset,'y':y+10}]})
    session.send('Input.dispatchTouchEvent',{'type':'touchEnd','touchPoints':[]})
    mobile.wait_for_function('(start)=>Math.abs(window.__holo.root.rotation.y-start)>.15', arg=start, timeout=60000)
    assert mobile.evaluate('document.documentElement.scrollWidth <= innerWidth')
    mobile.screenshot(path=str(root/'renders/mobile-touch.png'),full_page=True)
    context.close()
    browser.close()
assert not errors, errors
(root/'browser-validation.json').write_text(json.dumps({'ready':True,'drag':True,'flip_return':True,'foil_slider':True,'auto_reset':True,'save_image':True,'mobile_no_overflow':True,'console_errors':errors,'emulated_mobile_touch_drag_and_flip':True,'physical_touch_device':'not tested','source':sys.argv[1] if len(sys.argv)>1 else 'local HTTP'},indent=2))
print('PASS: GLB, textures, drag, flip/return, foil, auto/reset, image saving, mobile layout; no console errors')
