"""Apply this card's light palette and reference back to the generated scene."""
import bpy, json, math
from pathlib import Path

r=Path(__file__).resolve().parent
cfg=json.loads((r/'card-config.json').read_text())
s=bpy.context.scene
s.cycles.use_denoising=False
s.cycles.samples=24
# Use the same registered material layout in the Blender and web viewers.
main=bpy.data.materials['01 · 主体 + 背景 / 核心合成']
safe=main.node_tree.nodes['素材排版安全区']
ox,oy=cfg['safeArea']['offset']
safe.inputs[2].default_value=(ox,oy,0)
for n in main.node_tree.nodes:
    if n.type=='BSDF_PRINCIPLED':
        n.inputs['Metallic'].default_value=.12
        n.inputs['Roughness'].default_value=.65
gold=bpy.data.materials['04 · 古金压边']
for n in gold.node_tree.nodes:
    if n.type=='BSDF_PRINCIPLED':
        n.inputs['Base Color'].default_value=(.72,.57,.32,1)

m=bpy.data.materials['05 · 背面靛蓝'];m.name='05 · 珍珠浅蓝 / 陪伴寄语 / No.0002'
t=m.node_tree;t.nodes.clear()
uv=t.nodes.new('ShaderNodeTexCoord')
mirror=t.nodes.new('ShaderNodeVectorMath');mirror.operation='MULTIPLY_ADD'
mirror.inputs[1].default_value=(-1,1,1);mirror.inputs[2].default_value=(1,0,0)
t.links.new(uv.outputs['UV'],mirror.inputs[0])
bg=t.nodes.new('ShaderNodeTexImage');bg.image=bpy.data.images.load(str(r/'assets/back-background.png'));bg.image.pack()
text=t.nodes.new('ShaderNodeTexImage');text.image=bpy.data.images.load(str(r/'assets/back-text.png'));text.image.pack()
for n in (bg,text):t.links.new(mirror.outputs['Vector'],n.inputs['Vector'])
mix=t.nodes.new('ShaderNodeMixRGB');mix.blend_type='MIX'
t.links.new(bg.outputs['Color'],mix.inputs[1]);t.links.new(text.outputs['Color'],mix.inputs[2]);t.links.new(text.outputs['Alpha'],mix.inputs[0])
b=t.nodes.new('ShaderNodeBsdfPrincipled');b.inputs['Metallic'].default_value=.12;b.inputs['Roughness'].default_value=.65
t.links.new(mix.outputs['Color'],b.inputs['Base Color']);t.links.new(mix.outputs['Color'],b.inputs['Emission Color']);b.inputs['Emission Strength'].default_value=.2
out=t.nodes.new('ShaderNodeOutputMaterial');t.links.new(b.outputs['BSDF'],out.inputs['Surface'])
s.world.node_tree.nodes['Background'].inputs['Color'].default_value=(.78,.88,1,1)
s.world.node_tree.nodes['Background'].inputs['Strength'].default_value=.65
s['作品']='管小科 · 光华门 · No.0002 · 向阳校园超典藏'
s['背面署名']='西南财经大学 · 管理科学与工程学院'
s['降噪说明']='当前 Blender 不支持 OpenImageDenoise，已关闭降噪，保持可渲染。'
s.frame_set(25);s.render.filepath=str(r/'renders/hero.png')
bpy.ops.wm.save_as_mainfile(filepath=str(r/'card.blend'))
bpy.ops.render.render(write_still=True)
s.frame_set(49);s.cycles.samples=16;s.render.resolution_percentage=75;s.render.filepath=str(r/'renders/angled.png')
bpy.ops.render.render(write_still=True)
pivot=bpy.data.objects['转卡控制 · 播放时间线预览'];pivot.animation_data_clear();pivot.rotation_euler=(0,0,math.pi)
s.render.filepath=str(r/'renders/back.png')
bpy.ops.render.render(write_still=True)
print('FRONT, ANGLED AND TEXTURED BACK RENDERED')
