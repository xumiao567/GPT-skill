"""Create exact typography layers from blank transparent canvases."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

root = Path(__file__).parent
serif = '/usr/share/fonts/opentype/noto/NotoSerifCJK-Regular.ttc'
sans = '/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
bold = '/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc'
latin = '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
ink = '#244d60'
gold = '#8b6c30'

im = Image.new('RGBA', (1024,1536), (0,0,0,0))
d = ImageDraw.Draw(im)
def text(x,y,value,size,font=serif,color=ink,anchor='mm',halo=False):
    d.text((x,y),value,font=ImageFont.truetype(font,size),fill=color,anchor=anchor,
           stroke_width=1 if halo else 0,stroke_fill=(255,255,255,190))
text(74,90,'ULTRA COLLECTOR · 超典藏',21,sans,anchor='lm',halo=True)
text(76,162,'管小科',82,serif,anchor='lm',halo=True)
text(78,229,'光华门 · 向阳校园',24,sans,anchor='lm',halo=True)
text(938,96,'No.0002',26,latin,anchor='rm',halo=True)
text(512,1419,'向阳而行 · 与你同行',39,serif,halo=True)
text(512,1474,'GUAN XIAOKE · CAMPUS COMPANION',19,latin,halo=True)
im.save(root/'assets/text.png')

im = Image.new('RGBA',(1024,1536),(0,0,0,0))
d = ImageDraw.Draw(im)
text(512,137,'GUAN XIAOKE · CAMPUS COMPANION',22,latin,gold)
text(512,381,'管小科',81,serif,ink)
text(512,462,'温 暖  ·  陪 伴',24,sans,gold)
for y,value in zip((724,810,896,982),('把温暖藏进日常，','把陪伴写进成长。','在每一个值得记住的校园瞬间，','管小科，一直在你身边。')):
    text(512,y,value,36,serif,ink)
text(512,1100,'西南财经大学',27,bold,ink)
text(512,1150,'管理科学与工程学院',27,sans,ink)
text(512,1282,'No.0002',64,latin,gold)
text(512,1386,'超 典 藏  ·  向 阳 校 园 系 列',23,sans,gold)
im.save(root/'assets/back-text.png')
print('Exact front/back typography created, No.0002 / 西南财经大学')
