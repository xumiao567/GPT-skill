from pathlib import Path
import base64
from playwright.sync_api import sync_playwright

r=Path(__file__).resolve().parent
with sync_playwright() as p:
    b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--enable-webgl','--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    page=b.new_page(viewport={'width':1440,'height':1000})
    page.goto('http://127.0.0.1:4182')
    page.wait_for_function('window.__holo?.ready===true',timeout=60000)
    page.evaluate('''()=>{
      const h=window.__holo;h.renderer.setAnimationLoop(null);h.renderer.setPixelRatio(1);
      h.renderer.setSize(1024,1536,false);h.composer.setSize(1024,1536);
      Object.assign(h.camera,{left:-3.20,right:3.20,top:4.80,bottom:-4.80});h.camera.updateProjectionMatrix();
      h.root.rotation.set(0,0,0);h.root.updateMatrixWorld(true);h.uniforms.uView.value.set(0,0,1);h.uniforms.uTime.value=1;
      h.composer.render();
    }''')
    for filename,back in [('front-print.png',False),('back-print.png',True)]:
        data=page.evaluate('''(back)=>{const h=window.__holo;h.root.rotation.set(0,back?Math.PI:0,0);h.root.updateMatrixWorld(true);h.uniforms.uView.value.set(0,0,back?-1:1);h.composer.render();return h.renderer.domElement.toDataURL('image/png');}''',back)
        (r/'renders'/filename).write_bytes(base64.b64decode(data.split(',')[1]))
    b.close()
print('Exported 1024x1536 front and back previews from the actual web materials')
